<?php
defined('_JEXEC') or die;
require_once __DIR__ . '/helper.php';
$kofo = new ModKoFoHelper();
$kofo->set_ausgabe_array();
$ausgabe = $kofo->load_doc();
if($ausgabe == false) {
	$stat_m = $kofo->mail_check();
//	$adr = $kofo->getMail();
  $ausgabe = $kofo->mail_it($stat_m);
	}
	$status = $kofo->get_stat();
require_once(JModuleHelper::getLayoutPath('mod_kont_form'));
?>
