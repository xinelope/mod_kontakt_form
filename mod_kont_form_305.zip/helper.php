<?php
defined('_JEXEC') or die;
class ModKoFoHelper
 {
 	private $nachricht = array();
 	private $form_stat = 0;
 	private $mailAdr = "";
 	private $absender = "";
 	private $betreff = "";
 	public function set_ausgabe_array()
 	{
 		$this->nachricht[0] = "Bitte f&uuml;llen Sie alle Felder mit (*) aus und dr&uuml;cken Sie \"ABSENDEN\".";
		$this->nachricht[1] = "Die E-Mail-Adresse ist nicht korrekt, bitte &uuml;berpr&uuml;fen Sie die Eingabe!";
		$this->nachricht[2] = "Danke f&uuml;r Ihre Nachricht, Sie werden bald von uns h&ouml;ren!";
		$this->nachricht[3] = "Bitte geben Sie Ihren Namen an!";
		$this->nachricht[4] = "Bitte geben Sie Ihre Telefonnummer an!";
		$this->nachricht[5] = "Bitte teilen Sie Ihr Anliegen mit!";
 	}
 	public function load_doc()
 	{
 	  $module = JModuleHelper::getModule('mod_kont_form');
    $params = new JRegistry($module->params);
   	$this->mailAdr = $params->get('adresse', 'master@mindenmix.de');
   	$this->betreff = $params->get('betreff', 'via Webformular auf...');
    if ($_POST['firstcheck'] != "OK") {
      return $this->nachricht[0];
    }	else {
		return false;
   }
  }
  public function getMail($params){
	//
	$modul = JModuleHelper::getModule('mod_kontakt_form');
	$modulParams = new JRegistry();
	$modulParams->loadString($modul->params);
	$this->mailAdr = $modulParams->get('adresse','master@mindenmix.de');
	$this->betreff = $modulParams->get('betreff','Webformular auf...');
	return $this->mailAdr;
	}
  public function mail_check()
  {
   	$m_adr = (isset($_POST["EMail"]) ? $_POST["EMail"]:null);
	$standard = "@";
	$anzahl = similar_text($m_adr, $standard);
	if($anzahl!=1) { $mail_stat = 1;
	 } else  {
		list($user,$domain) = explode("@", $m_adr);
		if($user != "" && $domain != "")
			{
			 	if (getmxrr($domain, $mxlist) == FALSE)
				{ 	$mail_stat = 1;
				} else
				{	$mail_stat = 0; // alles OK
				}
			}
		else 	{ $mail_stat = 1;
			}
	 }
	 return $mail_stat;
   }
   public function get_stat()
   {
   	return $this->form_stat;
   }
   public function mail_it($status)
   {
	/* status = 0 ist gültige Mailadresse */
//  $_POST["Firma"] = (isset($_POST["Firma"]) ? $_POST["Firma"] : "");
	$_POST["Name"] = (isset($_POST["Name"]) ? $_POST["Name"] : "");
  $_POST["Telefon"] = (isset($_POST["Telefon"]) ? $_POST["Telefon"] : "");
	$_POST["EMail"] = (isset($_POST["EMail"]) ? $_POST["EMail"] : "");
  $_POST["Nachricht"] = (isset($_POST["Nachricht"]) ? $_POST["Nachricht"] : "");
//	$_POST["Strasse"] = (isset($_POST["Strasse"]) ? $_POST["Strasse"] : "");
//	$_POST["Ort"] = (isset($_POST["Ort"]) ? $_POST["Ort"] : "");
//	$_POST["Land"] = (isset($_POST["Land"]) ? $_POST["Land"] : "");
//	$_POST["Handy"] = (isset($_POST["Handy"]) ? $_POST["Handy"] : "");
//	$_POST["Fax"] = (isset($_POST["Fax"]) ? $_POST["Fax"] : "");
//  $_POST["Rueckruf"] = (isset($_POST["Rueckruf"]) ? $_POST["Rueckruf"] : "");
		if($_POST["Name"] == "") {$status = 3; }
		if($_POST["Telefon"] == "") {$status = 4; }
		if($_POST["Nachricht"] == "") {$status = 5; }
		if($status == 0)
		{
		$mail_subject = $_POST["Name"];
		$mail_subject .= " ";
		$mail_subject .= $this->betreff;
		$m_adr = rawurldecode($_POST["EMail"]);
		/* Alle Formularfeldnamen und Eintraege auslesen */
	 	$mail_text = "<h3>Sie haben eine Nachricht von <strong>".$mail_subject."</strong></h3><p style=\"color:#002266\">";

		reset($_POST);
			foreach($_POST as $var_name => $element)
			{
			  if($var_name != "abschicken" && $var_name != "leeren" && $var_name != "view" && $var_name != "option")
			  {
			  if($var_name == "EMail")
			   {
				   $mail_text .= "<strong>E-Mail: </strong><a href='mailto:'";
				   $mail_text .= rawurldecode($element);
				   $mail_text .= ">";
				   $mail_text .= rawurldecode($element);
				   $mail_text .= "</a></p><p style=\"color:#002266\">";
				   $mailadresse = rawurldecode($element);
         } elseif ($var_name != "firstcheck") {
			     if($element == "") $element = "<span style=\"color:#888\">keine Angabe</span>";
  			  //if($var_name == "Rueckruf" && $element == "on") $element = "Ja";
  			   $mail_text .= "<strong>";
  			   $mail_text .= rawurldecode($var_name);
  			   $mail_text .= ": </strong>";
  			   if($var_name == "Nachricht") $mail_text .= "<br>";
  			   $mail_text .= rawurldecode($element);
  			   $mail_text .= "</p><p style=\"color:#002266\">";
  			   $_POST[$var_name] = "";
			   }
			  }
		  	  }
		$mail_text .= "<br>";
		$mail_text .= "<br>";
		$mail_text .= "Diese Nachricht wurde über das Webformular verschickt.";
/* #################################################### */
	  $mailer = JFactory::getMailer();
    $config = JFactory::getConfig();
    $sender = array(
        $config->get( 'mailfrom' ),
        $config->get( 'fromname' )
        );
    $mailer->setSender($sender);
    $recipient = array( $this->mailAdr );
    $mailer->addRecipient($recipient);
    $mailer->setSubject($mail_subject);
    $mailer->isHTML(true);
    $mailer->Encoding = 'base64';
//
    $mailer->setBody($mail_text);
    $send = $mailer->Send();
    $ausgabe = $this->nachricht[2];
		$this->form_stat = 99;
	} else {
	$this->form_stat = 1;
	$ausgabe = $this->nachricht[$status];
	}
	return $ausgabe;
	}
  }
?>
