<?php
defined( '_JEXEC' ) or die( 'Restricted Access' );
$doc = JFactory::getDocument();
$doc->addScript("".JURI::root()."modules/mod_kont_form/mod_kont_form.js");
$urik = JUri::getInstance();
$adr = $urik->toString();
?>
<link rel="stylesheet" href="<?php echo JURI::root(); ?>modules/mod_kont_form/css/mod_kont_form.css" type="text/css" media="all" />
<script type="text/javascript" src="<?php echo JURI::root(); ?>modules/mod_kont_form/mod_kont_form.js"></script>
<!-- Test
<link href="../css/mod_kont_form.css" rel="stylesheet" type="text/css" />
-->
<p id="ersteMeldung"></p>
<p id="meldung"><?php echo $ausgabe; ?></p>
<form method="POST" action="<?php echo $adr; ?>" name="Kontaktformular" accept-charset="UTF-8" id="Kontaktformular">
   <fieldset class="form_sec">
     <section>
       <label for="Name">Vorname, Name</label>
       <input id="Name" name="Name" size="40" value="<?php echo rawurldecode($_POST["Name"]); ?>" />
     </section>
     <section>
       <label for="Telefon">Telefon</label>
       <input size="40" id="Telefon" name="Telefon" value="<?php echo rawurldecode($_POST["Telefon"]); ?>" />
     </section>
     <section>
       <label for="EMail">E-Mail</label>
       <input name="EMail" id="EMail" type="text" size="40" value="<?php echo rawurldecode($_POST["EMail"]); ?>" />
     </section>
     <section>
       <label for="Nachricht">Ihre Nachricht</label>
       <textarea name="Nachricht" cols="45" rows="5" id="Nachricht"></textarea>
     </section>
   </fieldset>
   <div>
        <input id="abschicken" name="abschicken" id="abschicken" type="button" value="ABSENDEN" onclick="checkForm()" />
        <input id="leeren" name="leeren" type="button" value="Eingaben l&ouml;schen" onclick="neuladen()" />
        <input id="status" type="hidden" value="<?php echo $status; ?>" />
        <input id="firstcheck" name="firstcheck" type="hidden" value="<?php echo rawurldecode($_POST["firstcheck"]); ?>" />
    </div>

  </form>
  <script type="application/javascript">document.getElementById('Kontaktformular').style.display = (document.getElementById('status').value == 99)? "none" : "block";
  </script>
