window.onload = function()
 {
	if(document.getElementById("status").value == 99)
  {
  document.getElementById("Kontaktformular").style.display = "none";
  document.getElementById("ersteMeldung").style.display = "none";
  }else if(document.getElementById("status").value == 2)
  {
  document.getElementById("ersteMeldung").style.display = "none";
  }
 }
//
var neuladen = function()
 {
	var feld = ['Name','Telefon','EMail','Nachricht'];
	for(var anteile in feld)
		{
		document.getElementById(feld[anteile]).value = "";
		}
  }
//
var checkForm = function() {
  fehler = "Fehlende Eingabe in einem Pflichtfeld. Bitte geben Sie '";
  fehler2 = "";
  stat= 0;
  //
  if(document.getElementById("Name").value ==""){
       document.getElementById("Name").style.border = "1px solid red";
       document.getElementById("Name").focus();
        fehler2 = "Name";stat= 1;
    }
    else {
     document.getElementById("Name").style.border = "1px solid silver";
     //
     if(document.getElementById("Telefon").value ==""){
       document.getElementById("Telefon").style.border = "1px solid red";
       document.getElementById("Telefon").focus();
        fehler2 = "Telefon";stat= 2;
      }else{
        document.getElementById("Telefon").style.border = "1px solid silver";
        if(document.getElementById("Nachricht").value ==""){
        document.getElementById("Nachricht").style.border = "1px solid red";
        document.getElementById("Nachricht").focus();
        fehler2 = "Nachricht";stat= 3;
        }else {
          document.getElementById("Nachricht").style.border = "1px solid silver";
          if(document.getElementById("EMail").value ==""){
            document.getElementById("EMail").style.border = "1px solid red";
          document.getElementById("EMail").focus();
          fehler2 = "E-Mail";stat= 5;
          }else{
            document.getElementById("EMail").style.border = "1px solid silver";
          }
        }
      }
     }
    if(stat == 0) {
    document.getElementById("firstcheck").value = "OK";
    document.forms["Kontaktformular"].submit();
  }
  else{
    fehler = fehler + fehler2;
    fehler = fehler + "' an.";
    document.getElementById("meldung").innerHTML = fehler;
    document.getElementById("firstcheck").value = "0";
  }
}
